/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dk.model;

import org.springframework.data.annotation.Id;

/**
 *
 * @author sourabh_deshkulkarni
 */
public class Api {
    @Id
    private String id;
    private String title;
    private String summary;
    private String rating;
    private String name;
    private String label;
    private String author;
    private String description;
    private String type;
    private String downloads;
    private String useCount;
    private String sampleUrl;
    private String downloadUrl;
    private String dateModified;
    private String remoteFeed;
    private String numComments;
    private String commentsUrl;
    private String tags;
    private String category;
    private String protocols;
    private String serviceEndpoint;
    private String version;
    private String wsdl;
    private String dataFormats;
    private String apiGroup;
    private String example;
    private String clientInstall;
    private String authentication;
    private String ssl;
    private String readOnly;
    private String vendorApiKits;
    private String communityApiKits;
    private String blog;
    private String forum;
    private String support;
    private String accountReq;
    private String commercial;
    private String managedBy;
    private String dataLicensing;
    private String fees;
    private String limits;
    private String terms;
    private String company;
    private String updated;

    public Api(String id, String title, String summary, String rating, String name, String label, String author, String description, String type, String downloads, String useCount, String sampleUrl, String downloadUrl, String dateModified, String remoteFeed, String numComments, String commentsUrl, String tags, String category, String protocols, String serviceEndpoint, String version, String wsdl, String dataFormats, String apiGroup, String example, String clientInstall, String authentication, String ssl, String readOnly, String vendorApiKits, String communityApiKits, String blog, String forum, String support, String accountReq, String commercial, String managedBy, String dataLicensing, String fees, String limits, String terms, String company, String updated) {
        this.id = id;
        this.title = title;
        this.summary = summary;
        this.rating = rating;
        this.name = name;
        this.label = label;
        this.author = author;
        this.description = description;
        this.type = type;
        this.downloads = downloads;
        this.useCount = useCount;
        this.sampleUrl = sampleUrl;
        this.downloadUrl = downloadUrl;
        this.dateModified = dateModified;
        this.remoteFeed = remoteFeed;
        this.numComments = numComments;
        this.commentsUrl = commentsUrl;
        this.tags = tags;
        this.category = category;
        this.protocols = protocols;
        this.serviceEndpoint = serviceEndpoint;
        this.version = version;
        this.wsdl = wsdl;
        this.dataFormats = dataFormats;
        this.apiGroup = apiGroup;
        this.example = example;
        this.clientInstall = clientInstall;
        this.authentication = authentication;
        this.ssl = ssl;
        this.readOnly = readOnly;
        this.vendorApiKits = vendorApiKits;
        this.communityApiKits = communityApiKits;
        this.blog = blog;
        this.forum = forum;
        this.support = support;
        this.accountReq = accountReq;
        this.commercial = commercial;
        this.managedBy = managedBy;
        this.dataLicensing = dataLicensing;
        this.fees = fees;
        this.limits = limits;
        this.terms = terms;
        this.company = company;
        this.updated = updated;
    }
    
    
    
    
    
    
    

    public Api(){
    
}
    
    public Api(String id, String title, String summary){
        this.id = id;
        this.title = title;
        this.summary = summary;
                
    }
    
    /**
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * @return the title
     */
    public String getTitle() {
        return title;
    }

    /**
     * @param title the title to set
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * @return the summary
     */
    public String getSummary() {
        return summary;
    }

    /**
     * @param summary the summary to set
     */
    public void setSummary(String summary) {
        this.summary = summary;
    }

    @Override
    public String toString() {
        return "Api{" + "id=" + id + ", title=" + title + ", summary=" + summary + ", rating=" + rating + ", name=" + name + ", label=" + label + ", author=" + author + ", description=" + description + ", type=" + type + ", downloads=" + downloads + ", useCount=" + useCount + ", sampleUrl=" + sampleUrl + ", downloadUrl=" + downloadUrl + ", dateModified=" + dateModified + ", remoteFeed=" + remoteFeed + ", numComments=" + numComments + ", commentsUrl=" + commentsUrl + ", tags=" + tags + ", category=" + category + ", protocols=" + protocols + ", serviceEndpoint=" + serviceEndpoint + ", version=" + version + ", wsdl=" + wsdl + ", dataFormats=" + dataFormats + ", apiGroup=" + apiGroup + ", example=" + example + ", clientInstall=" + clientInstall + ", authentication=" + authentication + ", ssl=" + ssl + ", readOnly=" + readOnly + ", vendorApiKits=" + vendorApiKits + ", communityApiKits=" + communityApiKits + ", blog=" + blog + ", forum=" + forum + ", support=" + support + ", accountReq=" + accountReq + ", commercial=" + commercial + ", managedBy=" + managedBy + ", dataLicensing=" + dataLicensing + ", fees=" + fees + ", limits=" + limits + ", terms=" + terms + ", company=" + company + ", updated=" + updated + '}';
    }
    
   

    /**
     * @return the rating
     */
    public String getRating() {
        return rating;
    }

    /**
     * @param rating the rating to set
     */
    public void setRating(String rating) {
        this.rating = rating;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the label
     */
    public String getLabel() {
        return label;
    }

    /**
     * @param label the label to set
     */
    public void setLabel(String label) {
        this.label = label;
    }

    /**
     * @return the author
     */
    public String getAuthor() {
        return author;
    }

    /**
     * @param author the author to set
     */
    public void setAuthor(String author) {
        this.author = author;
    }

    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * @param type the type to set
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * @return the downloads
     */
    public String getDownloads() {
        return downloads;
    }

    /**
     * @param downloads the downloads to set
     */
    public void setDownloads(String downloads) {
        this.downloads = downloads;
    }

    /**
     * @return the useCount
     */
    public String getUseCount() {
        return useCount;
    }

    /**
     * @param useCount the useCount to set
     */
    public void setUseCount(String useCount) {
        this.useCount = useCount;
    }

    /**
     * @return the sampleUrl
     */
    public String getSampleUrl() {
        return sampleUrl;
    }

    /**
     * @param sampleUrl the sampleUrl to set
     */
    public void setSampleUrl(String sampleUrl) {
        this.sampleUrl = sampleUrl;
    }

    /**
     * @return the downloadUrl
     */
    public String getDownloadUrl() {
        return downloadUrl;
    }

    /**
     * @param downloadUrl the downloadUrl to set
     */
    public void setDownloadUrl(String downloadUrl) {
        this.downloadUrl = downloadUrl;
    }

    /**
     * @return the dateModified
     */
    public String getDateModified() {
        return dateModified;
    }

    /**
     * @param dateModified the dateModified to set
     */
    public void setDateModified(String dateModified) {
        this.dateModified = dateModified;
    }

    /**
     * @return the remoteFeed
     */
    public String getRemoteFeed() {
        return remoteFeed;
    }

    /**
     * @param remoteFeed the remoteFeed to set
     */
    public void setRemoteFeed(String remoteFeed) {
        this.remoteFeed = remoteFeed;
    }

    /**
     * @return the numComments
     */
    public String getNumComments() {
        return numComments;
    }

    /**
     * @param numComments the numComments to set
     */
    public void setNumComments(String numComments) {
        this.numComments = numComments;
    }

    /**
     * @return the commentsUrl
     */
    public String getCommentsUrl() {
        return commentsUrl;
    }

    /**
     * @param commentsUrl the commentsUrl to set
     */
    public void setCommentsUrl(String commentsUrl) {
        this.commentsUrl = commentsUrl;
    }

    /**
     * @return the tags
     */
    public String getTags() {
        return tags;
    }

    /**
     * @param tags the tags to set
     */
    public void setTags(String tags) {
        this.tags = tags;
    }

    /**
     * @return the category
     */
    public String getCategory() {
        return category;
    }

    /**
     * @param category the category to set
     */
    public void setCategory(String category) {
        this.category = category;
    }

    /**
     * @return the protocols
     */
    public String getProtocols() {
        return protocols;
    }

    /**
     * @param protocols the protocols to set
     */
    public void setProtocols(String protocols) {
        this.protocols = protocols;
    }

    /**
     * @return the serviceEndpoint
     */
    public String getServiceEndpoint() {
        return serviceEndpoint;
    }

    /**
     * @param serviceEndpoint the serviceEndpoint to set
     */
    public void setServiceEndpoint(String serviceEndpoint) {
        this.serviceEndpoint = serviceEndpoint;
    }

    /**
     * @return the version
     */
    public String getVersion() {
        return version;
    }

    /**
     * @param version the version to set
     */
    public void setVersion(String version) {
        this.version = version;
    }

    /**
     * @return the wsdl
     */
    public String getWsdl() {
        return wsdl;
    }

    /**
     * @param wsdl the wsdl to set
     */
    public void setWsdl(String wsdl) {
        this.wsdl = wsdl;
    }

    /**
     * @return the dataFormats
     */
    public String getDataFormats() {
        return dataFormats;
    }

    /**
     * @param dataFormats the dataFormats to set
     */
    public void setDataFormats(String dataFormats) {
        this.dataFormats = dataFormats;
    }

    /**
     * @return the apiGroup
     */
    public String getApiGroup() {
        return apiGroup;
    }

    /**
     * @param apiGroup the apiGroup to set
     */
    public void setApiGroup(String apiGroup) {
        this.apiGroup = apiGroup;
    }

    /**
     * @return the example
     */
    public String getExample() {
        return example;
    }

    /**
     * @param example the example to set
     */
    public void setExample(String example) {
        this.example = example;
    }

    /**
     * @return the clientInstall
     */
    public String getClientInstall() {
        return clientInstall;
    }

    /**
     * @param clientInstall the clientInstall to set
     */
    public void setClientInstall(String clientInstall) {
        this.clientInstall = clientInstall;
    }

    /**
     * @return the authentication
     */
    public String getAuthentication() {
        return authentication;
    }

    /**
     * @param authentication the authentication to set
     */
    public void setAuthentication(String authentication) {
        this.authentication = authentication;
    }

    /**
     * @return the ssl
     */
    public String getSsl() {
        return ssl;
    }

    /**
     * @param ssl the ssl to set
     */
    public void setSsl(String ssl) {
        this.ssl = ssl;
    }

    /**
     * @return the readOnly
     */
    public String getReadOnly() {
        return readOnly;
    }

    /**
     * @param readOnly the readOnly to set
     */
    public void setReadOnly(String readOnly) {
        this.readOnly = readOnly;
    }

    /**
     * @return the vendorApiKits
     */
    public String getVendorApiKits() {
        return vendorApiKits;
    }

    /**
     * @param vendorApiKits the vendorApiKits to set
     */
    public void setVendorApiKits(String vendorApiKits) {
        this.vendorApiKits = vendorApiKits;
    }

    /**
     * @return the communityApiKits
     */
    public String getCommunityApiKits() {
        return communityApiKits;
    }

    /**
     * @param communityApiKits the communityApiKits to set
     */
    public void setCommunityApiKits(String communityApiKits) {
        this.communityApiKits = communityApiKits;
    }

    /**
     * @return the blog
     */
    public String getBlog() {
        return blog;
    }

    /**
     * @param blog the blog to set
     */
    public void setBlog(String blog) {
        this.blog = blog;
    }

    /**
     * @return the forum
     */
    public String getForum() {
        return forum;
    }

    /**
     * @param forum the forum to set
     */
    public void setForum(String forum) {
        this.forum = forum;
    }

    /**
     * @return the support
     */
    public String getSupport() {
        return support;
    }

    /**
     * @param support the support to set
     */
    public void setSupport(String support) {
        this.support = support;
    }

    /**
     * @return the accountReq
     */
    public String getAccountReq() {
        return accountReq;
    }

    /**
     * @param accountReq the accountReq to set
     */
    public void setAccountReq(String accountReq) {
        this.accountReq = accountReq;
    }

    /**
     * @return the commercial
     */
    public String getCommercial() {
        return commercial;
    }

    /**
     * @param commercial the commercial to set
     */
    public void setCommercial(String commercial) {
        this.commercial = commercial;
    }

    /**
     * @return the managedBy
     */
    public String getManagedBy() {
        return managedBy;
    }

    /**
     * @param managedBy the managedBy to set
     */
    public void setManagedBy(String managedBy) {
        this.managedBy = managedBy;
    }

    /**
     * @return the dataLicensing
     */
    public String getDataLicensing() {
        return dataLicensing;
    }

    /**
     * @param dataLicensing the dataLicensing to set
     */
    public void setDataLicensing(String dataLicensing) {
        this.dataLicensing = dataLicensing;
    }

    /**
     * @return the fees
     */
    public String getFees() {
        return fees;
    }

    /**
     * @param fees the fees to set
     */
    public void setFees(String fees) {
        this.fees = fees;
    }

    /**
     * @return the limits
     */
    public String getLimits() {
        return limits;
    }

    /**
     * @param limits the limits to set
     */
    public void setLimits(String limits) {
        this.limits = limits;
    }

    /**
     * @return the terms
     */
    public String getTerms() {
        return terms;
    }

    /**
     * @param terms the terms to set
     */
    public void setTerms(String terms) {
        this.terms = terms;
    }

    /**
     * @return the company
     */
    public String getCompany() {
        return company;
    }

    /**
     * @param company the company to set
     */
    public void setCompany(String company) {
        this.company = company;
    }

    /**
     * @return the updated
     */
    public String getUpdated() {
        return updated;
    }

    /**
     * @param updated the updated to set
     */
    public void setUpdated(String updated) {
        this.updated = updated;
    }
    
}
