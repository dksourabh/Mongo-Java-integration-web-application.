/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dk.model;

/**
 *
 * @author sourabh_deshkulkarni
 */
public class Mashup {
    private String id;
    private String title;
    private String summary;
    private String rating;
    private String name;
    private String label;
    private String author;
    private String description;
    private String type;
    private String downloads;
    private String useCount;
    private String sampleUrl;
    private String dateModified;
    private String numComments;
    private String commentsUrl;
    private String tags;
    private String api;
    private String updated;

    public Mashup(String id, String title, String summary, String rating, String name, String label, String author, String description, String type, String downloads, String useCount, String sampleUrl, String dateModified, String numComments, String commentsUrl, String tags, String api, String updated) {
        this.id = id;
        this.title = title;
        this.summary = summary;
        this.rating = rating;
        this.name = name;
        this.label = label;
        this.author = author;
        this.description = description;
        this.type = type;
        this.downloads = downloads;
        this.useCount = useCount;
        this.sampleUrl = sampleUrl;
        this.dateModified = dateModified;
        this.numComments = numComments;
        this.commentsUrl = commentsUrl;
        this.tags = tags;
        this.api = api;
        this.updated = updated;
    }

    public Mashup() {
       //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String toString() {
        return "Mashup{" + "id=" + id + ", title=" + title + ", summary=" + summary + ", rating=" + rating + ", name=" + name + ", label=" + label + ", author=" + author + ", description=" + description + ", type=" + type + ", downloads=" + downloads + ", useCount=" + useCount + ", sampleUrl=" + sampleUrl + ", dateModified=" + dateModified + ", numComments=" + numComments + ", commentsUrl=" + commentsUrl + ", tags=" + tags + ", APIs=" + api + ", updated=" + updated + '}';
    }

    
    /**
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * @return the title
     */
    public String getTitle() {
        return title;
    }

    /**
     * @param title the title to set
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * @return the summary
     */
    public String getSummary() {
        return summary;
    }

    /**
     * @param summary the summary to set
     */
    public void setSummary(String summary) {
        this.summary = summary;
    }

    /**
     * @return the rating
     */
    public String getRating() {
        return rating;
    }

    /**
     * @param rating the rating to set
     */
    public void setRating(String rating) {
        this.rating = rating;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the label
     */
    public String getLabel() {
        return label;
    }

    /**
     * @param label the label to set
     */
    public void setLabel(String label) {
        this.label = label;
    }

    /**
     * @return the author
     */
    public String getAuthor() {
        return author;
    }

    /**
     * @param author the author to set
     */
    public void setAuthor(String author) {
        this.author = author;
    }

    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * @param type the type to set
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * @return the downloads
     */
    public String getDownloads() {
        return downloads;
    }

    /**
     * @param downloads the downloads to set
     */
    public void setDownloads(String downloads) {
        this.downloads = downloads;
    }

    /**
     * @return the useCount
     */
    public String getUseCount() {
        return useCount;
    }

    /**
     * @param useCount the useCount to set
     */
    public void setUseCount(String useCount) {
        this.useCount = useCount;
    }

    /**
     * @return the sampleUrl
     */
    public String getSampleUrl() {
        return sampleUrl;
    }

    /**
     * @param sampleUrl the sampleUrl to set
     */
    public void setSampleUrl(String sampleUrl) {
        this.sampleUrl = sampleUrl;
    }

    /**
     * @return the dateModified
     */
    public String getDateModified() {
        return dateModified;
    }

    /**
     * @param dateModified the dateModified to set
     */
    public void setDateModified(String dateModified) {
        this.dateModified = dateModified;
    }

    /**
     * @return the numComments
     */
    public String getNumComments() {
        return numComments;
    }

    /**
     * @param numComments the numComments to set
     */
    public void setNumComments(String numComments) {
        this.numComments = numComments;
    }

    /**
     * @return the commentsUrl
     */
    public String getCommentsUrl() {
        return commentsUrl;
    }

    /**
     * @param commentsUrl the commentsUrl to set
     */
    public void setCommentsUrl(String commentsUrl) {
        this.commentsUrl = commentsUrl;
    }

    /**
     * @return the tags
     */
    public String getTags() {
        return tags;
    }

    /**
     * @param tags the tags to set
     */
    public void setTags(String tags) {
        this.tags = tags;
    }

    /**
     * @return the APIs
     */
 

    /**
     * @return the updated
     */
    public String getUpdated() {
        return updated;
    }

    /**
     * @param updated the updated to set
     */
    public void setUpdated(String updated) {
        this.updated = updated;
    }
    
    
    
}
