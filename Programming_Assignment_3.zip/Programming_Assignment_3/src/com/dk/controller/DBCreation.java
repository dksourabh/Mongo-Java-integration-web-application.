package com.dk.controller;


import com.dk.model.Api;
import java.net.UnknownHostException;

import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;

import com.mongodb.MongoClient;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class DBCreation {

    public static final String DB_NAME = "sourabh_dk";
    public static final String API_COLLECTION = "Api";
    public static final String MONGO_HOST = "localhost";
    public static final int MONGO_PORT = 27017;

    public static void main(String[] args) throws IOException {
        String csvFile = "/Users/sourabh_deshkulkarni/Downloads/api.txt";
        BufferedReader br = null;
        String line = "";
        String cvsSplitBy = ",";
        try {

            MongoClient mongo = new MongoClient(
                    MONGO_HOST, MONGO_PORT);
            MongoOperations mongoOps = new MongoTemplate(mongo, DB_NAME);
            mongoOps.dropCollection(API_COLLECTION);
            br = new BufferedReader(new FileReader(csvFile));
            String previous = "";
            ArrayList<String> idList = new ArrayList<String>();
            while ((line = br.readLine()) != null) {

                // use comma as separator
                String[] records = line.split(cvsSplitBy);
                if (records != null) {
                    Api m = new Api(records[0], records[1], records[2], records[3],
                            records[4], records[5], records[6], records[7], records[8],
                            records[9], records[10], records[11], records[12], records[13],
                            records[14], records[15], records[16], records[17],records[18], records[19], records[20], records[21], records[22],
                            records[23], records[24], records[25], records[26], records[27],
                            records[28], records[29], records[30], records[31],records[32], records[33], records[34], records[35], records[36],
                            records[37], records[38], records[39], records[40],records[41],records[42],records[43]);
                    if (!idList.contains(records[0])) {
                        mongoOps.insert(m, API_COLLECTION);
                    }
                    System.out.println("Country [code= " + records[4]
                            + " , name=" + records[5] + "]");
                    idList.add(records[0]);
                    //previous = records[0];

                }
            }
            //Person p = new Person("113", "PankajKr", "Bangalore, India");
//            Api a = new Api("http://www.programmableweb.com/api/the-global-proteome-machine", "WebService1", "lol");
//            mongoOps.insert(a, API_COLLECTION);
//
//            Api a1 = mongoOps.findOne(
//                    new Query(Criteria.where("summary").is("Access to .tel DNS ")),
//                    Api.class, API_COLLECTION);
            Api a1 = mongoOps.findOne(
                    new Query(Criteria.where("id").regex("http://www.programmableweb.com/api/twilio-telegram")),
                    Api.class, API_COLLECTION);

            System.out.println("Collection found: " + a1);
//

//            mongo.close();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

    }

}
