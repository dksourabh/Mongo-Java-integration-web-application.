package com.dk.controller;

//import com.journaldev.spring.mongodb.model.Api;
import com.dk.model.Api;
import com.dk.model.Mashup;
import java.net.UnknownHostException;

import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;

import com.mongodb.MongoClient;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class SpringDataMongoDBMain {

    public static final String DB_NAME = "journaldev";
    public static final String API_COLLECTION = "Api";
    public static final String MASHUP_COLLECTION = "mashup";
    public static final String MONGO_HOST = "localhost";
    public static final int MONGO_PORT = 27017;

    private String rating;

    private String tags;
    private String mashupTags;
    private String category;
    private String protocols;

    private String updated;
    private String mashupUpdated;
    private String allSearch;
    private String mashupAllSearch;
    private String mashupApis;
    private List<Api> a1 = new ArrayList<Api>();
    private List<Api> a2 = new ArrayList<Api>();
    private List<Mashup> a3 = new ArrayList<Mashup>();
    private List<Mashup> a4 = new ArrayList<Mashup>();

    public String execute() throws Exception {

        //String csvFile = "/Users/sourabh_deshkulkarni/Downloads/api.txt";
        BufferedReader br = null;
        //String line = "";
        //String cvsSplitBy = ",";
        ArrayList<String> apiParameters = new ArrayList<String>();
        apiParameters.add("id");
        apiParameters.add("title");
        apiParameters.add("summary");
        apiParameters.add("rating");
        apiParameters.add("name");
        apiParameters.add("label");
        apiParameters.add("author");
        apiParameters.add("description");
        apiParameters.add("type");
        apiParameters.add("downloads");
        apiParameters.add("useCount");
        apiParameters.add("sampleUrl");
        apiParameters.add("downloadUrl");
        apiParameters.add("dateModified");
        apiParameters.add("remoteFeed");
        apiParameters.add("numComments");
        apiParameters.add("commentsUrl");
        apiParameters.add("tags");
        apiParameters.add("category");
        apiParameters.add("serviceEndpoint");
        apiParameters.add("version");
        apiParameters.add("wsdl");
        apiParameters.add("dataFormats");
        apiParameters.add("apiGroup");
        apiParameters.add("example");
        apiParameters.add("clientInstall");
        apiParameters.add("authentication");
        apiParameters.add("ssl");
        apiParameters.add("readOnly");
        apiParameters.add("vendorApiKits");
        apiParameters.add("communityApiKits");
        apiParameters.add("blog");
        apiParameters.add("forum");
        apiParameters.add("support");
        apiParameters.add("commercial");
        apiParameters.add("managedBy");
        apiParameters.add("dataLicensing");
        apiParameters.add("fees");
        apiParameters.add("limits");
        apiParameters.add("terms");
        apiParameters.add("company");
        apiParameters.add("updated");

        //  List<Api> a2 = new ArrayList<Api>();
        HashMap<String, String> map = new HashMap<String, String>();

        try {
            MongoClient mongo = new MongoClient(
                    MONGO_HOST, MONGO_PORT);
            MongoOperations mongoOps = new MongoTemplate(mongo, DB_NAME);

            map.put("rating", rating);

            map.put("updated", updated);

            map.put("category", category);
            map.put("tags", tags);
            map.put("protocols", protocols);
            if (allSearch == null || "".equalsIgnoreCase(allSearch)) {
                Criteria criteria = new Criteria();

                List<Criteria> docCriterias = new ArrayList<Criteria>();

                Query q1 = new Query();
                Iterator it = map.entrySet().iterator();
                while (it.hasNext()) {
                    Map.Entry pair = (Map.Entry) it.next();
                    if (pair.getValue() != null && !"".equalsIgnoreCase(String.valueOf(pair.getValue()))) {
                        if (String.valueOf(pair.getKey()).contains("rating")) {
                            if (String.valueOf(pair.getValue()).contains("<")) {
                                System.out.println("I am in less than part");
                                docCriterias.add(Criteria.where(String.valueOf(pair.getKey())).lt(String.valueOf(pair.getValue()).replaceAll("<", "")));
                            } else if (String.valueOf(pair.getValue()).contains(">")) {
                                System.out.println("I am in greater than part");
                                docCriterias.add(Criteria.where(String.valueOf(pair.getKey())).gt(String.valueOf(pair.getValue()).replaceAll(">", "")));
                            } else {
                                System.out.println("I am in equal  part");
                                docCriterias.add(Criteria.where(String.valueOf(pair.getKey())).regex(String.valueOf(pair.getValue())));
                            }

                        } else {
                            docCriterias.add(Criteria.where(String.valueOf(pair.getKey())).regex(String.valueOf(pair.getValue())));
                            // q1= q1.addCriteria(Criteria.where(String.valueOf(pair.getKey())).regex(String.valueOf(pair.getValue())));
                        }
                    }
                    System.out.println(pair.getKey() + " = " + pair.getValue());
                    it.remove(); // avoids a ConcurrentModificationException
                }
                criteria = criteria.andOperator(docCriterias.toArray(new Criteria[map.size()]));           

                setA1(mongoOps.find(
                        new Query(criteria),
                        Api.class, API_COLLECTION));
                System.out.println(getA1().size());
                int i = 0;
                for (Api a0 : getA1()) {
                    System.out.println("Collection found: " + a0 + "//" + i++);
                }
                a2.addAll(a1);
            } else {
               System.out.println("I am in else part");
                ArrayList<String> listString = new ArrayList<String>();
                String[] arrString = allSearch.split(",");
                if (arrString.length >1) {

                    for (String str : arrString) {
                        System.out.println("Words: " + str);
                        listString.add(str);
                    }
                }
                System.out.println("Array length:"+arrString.length);
                if(arrString.length ==1){
                    listString.add(allSearch);
                }
               
                ArrayList<String> tempList = new ArrayList<String>();
                if(listString.size()>1){
                    System.out.println("I am in more than 1");
                    
                for (String temp : listString) {
                    a1 = mongoOps.find(
                            new Query(Criteria.where("title").regex(temp).and("description").regex(temp).and("summary").regex(temp)),
                            Api.class, API_COLLECTION);
                   // System.out.println(temp + "//" + mash.getId());
                    for (Api m : a1) {
                        if (tempList.contains(m.getId())) {
                            a2.add(m);
                        }
                    }
                    for (Api m : a1) {
                        tempList.add(m.getId());
                    }

                }
                }else{
                    System.out.println("First list element: "+listString.get(0));
                     a1 = mongoOps.find(
                            new Query(Criteria.where("title").regex(listString.get(0)).and("description").regex(listString.get(0)).and("summary").regex(listString.get(0))),
                            Api.class, API_COLLECTION);
                   // System.out.println(temp + "//" + mash.getId());
                    //for (Api m : a1) {
                     //   if (tempList.contains(m.getId())) {
                            a2.addAll(a1);
                       // }
                    //}
                }
            }
            int i = 0;
            for (Api a0 : a2) {
                System.out.println("Collection found: " + a0 + "//" + i++);
            }
//            mongoOps.dropCollection(API_COLLECTION);
//            mongo.close();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        return "success";
    }

    public String executeMashUp() throws Exception {

        //String csvFile = "/Users/sourabh_deshkulkarni/Downloads/api.txt";
        BufferedReader br = null;
        //String line = "";
        //String cvsSplitBy = ",";
        ArrayList<String> mashupParameters = new ArrayList<String>();
        mashupParameters.add("id");
        mashupParameters.add("title");
        mashupParameters.add("summary");
        mashupParameters.add("rating");
        mashupParameters.add("name");
        mashupParameters.add("label");
        mashupParameters.add("author");
        mashupParameters.add("description");
        mashupParameters.add("type");
        mashupParameters.add("downloads");
        mashupParameters.add("useCount");
        mashupParameters.add("sampleUrl");
        mashupParameters.add("dateModified");
        mashupParameters.add("remoteFeed");
        mashupParameters.add("numComments");
        mashupParameters.add("commentsUrl");
        mashupParameters.add("tags");
        mashupParameters.add("api");
        mashupParameters.add("updated");

        //  List<Api> a2 = new ArrayList<Api>();
        HashMap<String, String> map = new HashMap<String, String>();

        try {
            MongoClient mongo = new MongoClient(
                    MONGO_HOST, MONGO_PORT);
            MongoOperations mongoOps = new MongoTemplate(mongo, DB_NAME);

            map.put("updated", mashupUpdated);

            map.put("api", mashupApis);

            map.put("tags", mashupTags);

            if (mashupAllSearch == null || "".equalsIgnoreCase(mashupAllSearch)) {
                Criteria criteria = new Criteria();

                List<Criteria> docCriterias = new ArrayList<Criteria>();

                Query q1 = new Query();
                Iterator it = map.entrySet().iterator();
                while (it.hasNext()) {
                    Map.Entry pair = (Map.Entry) it.next();
                    if (pair.getValue() != null && !"".equalsIgnoreCase(String.valueOf(pair.getValue()))) {

                        docCriterias.add(Criteria.where(String.valueOf(pair.getKey())).regex(String.valueOf(pair.getValue())));
                        // q1= q1.addCriteria(Criteria.where(String.valueOf(pair.getKey())).regex(String.valueOf(pair.getValue())));

                    }
                    System.out.println(pair.getKey() + " = " + pair.getValue());
                    it.remove(); // avoids a ConcurrentModificationException
                }
                criteria = criteria.andOperator(docCriterias.toArray(new Criteria[map.size()]));
//            for (String parameter : apiParameters) {
//                System.out.println(parameter);
//                a1 = mongoOps.find(
//                        new Query(Criteria.where(parameter).regex("DNS")),
//                        Api.class, API_COLLECTION);
//                a2.addAll(a1);
//            }

                setA3(mongoOps.find(
                        new Query(criteria),
                        Mashup.class, MASHUP_COLLECTION));
                //System.out.println(getA1().size());
                int i = 0;
                for (Mashup a0 : getA3()) {
                    System.out.println("Collection found: " + a0 + "//" + i++);
                }
                a4.addAll(a3);
            } else {
                System.out.println("I am in else part");
                ArrayList<String> listString = new ArrayList<String>();
                String[] arrString = mashupAllSearch.split(",");
                if (arrString.length> 1) {

                    for (String str : arrString) {
                        System.out.println("Words:" + str);
                        listString.add(str);
                    }
                }
                if(arrString.length ==1){
                    listString.add(mashupAllSearch);
                }
                // for (String parameter : mashupParameters) {
                //System.out.println("Mashup all search:" + mashupAllSearch + "//" + parameter);
                //System.out.println(parameter);
                ArrayList<String> tempList = new ArrayList<String>();
              if(listString.size()>1){
                  System.out.println("I am in greater than one Mashup");
                for (String temp : listString) {
                    a3 = mongoOps.find(
                            new Query(Criteria.where("title").regex(temp).and("summary").regex(temp).and("description").regex(temp)),
                            Mashup.class, MASHUP_COLLECTION);
                    System.out.println(a3.size() + "// Size");
                    System.out.println("Collection: "+a3);
                    for (Mashup m : a3) {
                        if (tempList.contains(m.getId())) {
                            a4.add(m);
                        }
                    }
                    for (Mashup m : a3) {
                        tempList.add(m.getId());
                    }

                }
              }else{
                   System.out.println("First list element: "+listString.get(0));
                     a3 = mongoOps.find(
                            new Query(Criteria.where("title").regex(listString.get(0)).and("description").regex(listString.get(0)).and("summary").regex(listString.get(0))),
                            Mashup.class, MASHUP_COLLECTION);
                   // System.out.println(temp + "//" + mash.getId());
                    //for (Api m : a1) {
                     //   if (tempList.contains(m.getId())) {
                            a4.addAll(a3);
              }
                // }
            }
            int i = 0;
            for (Mashup a0 : a4) {
                System.out.println("Collection found: " + a0 + "//" + i++);
            }
//            mongoOps.dropCollection(API_COLLECTION);
//            mongo.close();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        return "success";
    }

    public static void main(String[] args) throws IOException {

        String csvFile = "/Users/sourabh_deshkulkarni/Downloads/api.txt";
        BufferedReader br = null;
        String line = "";
        String cvsSplitBy = ",";
        ArrayList<String> apiParameters = new ArrayList<String>();
        apiParameters.add("id");
        apiParameters.add("title");
        apiParameters.add("summary");
        apiParameters.add("rating");
        apiParameters.add("name");
        apiParameters.add("label");
        apiParameters.add("author");
        apiParameters.add("description");
        apiParameters.add("type");
        apiParameters.add("downloads");
        apiParameters.add("useCount");
        apiParameters.add("sampleUrl");
        apiParameters.add("downloadUrl");
        apiParameters.add("dateModified");
        apiParameters.add("remoteFeed");
        apiParameters.add("numComments");
        apiParameters.add("commentsUrl");
        apiParameters.add("tags");
        apiParameters.add("category");
        apiParameters.add("serviceEndpoint");
        apiParameters.add("version");
        apiParameters.add("wsdl");
        apiParameters.add("dataFormats");
        apiParameters.add("apiGroup");
        apiParameters.add("example");
        apiParameters.add("clientInstall");
        apiParameters.add("authentication");
        apiParameters.add("ssl");
        apiParameters.add("readOnly");
        apiParameters.add("vendorApiKits");
        apiParameters.add("communityApiKits");
        apiParameters.add("blog");
        apiParameters.add("forum");
        apiParameters.add("support");
        apiParameters.add("commercial");
        apiParameters.add("managedBy");
        apiParameters.add("dataLicensing");
        apiParameters.add("fees");
        apiParameters.add("limits");
        apiParameters.add("terms");
        apiParameters.add("company");
        apiParameters.add("updated");

        List<Api> a2 = new ArrayList<Api>();
        HashMap<String, String> map = new HashMap<String, String>();

        try {
            MongoClient mongo = new MongoClient(
                    MONGO_HOST, MONGO_PORT);
            MongoOperations mongoOps = new MongoTemplate(mongo, DB_NAME);

            map.put("rating", "3.5");
            map.put("id", null);

            map.put("updated", null);

            map.put("category", "Social");
            map.put("tags", null);
            map.put("protocols", "");

            Criteria criteria = new Criteria();

            List<Criteria> docCriterias = new ArrayList<Criteria>();

            Query q1 = new Query();
            Iterator it = map.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry pair = (Map.Entry) it.next();
                if (pair.getValue() != null && !"".equalsIgnoreCase(String.valueOf(pair.getValue()))) {
                    docCriterias.add(Criteria.where(String.valueOf(pair.getKey())).regex(String.valueOf(pair.getValue())));
                    // q1= q1.addCriteria(Criteria.where(String.valueOf(pair.getKey())).regex(String.valueOf(pair.getValue())));
                }
                System.out.println(pair.getKey() + " = " + pair.getValue());
                it.remove(); // avoids a ConcurrentModificationException
            }
            criteria = criteria.andOperator(docCriterias.toArray(new Criteria[map.size()]));
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

    }

    /**
     * @return the rating
     */
    public String getRating() {
        return rating;
    }

    /**
     * @param rating the rating to set
     */
    public void setRating(String rating) {
        this.rating = rating;
    }

    /**
     * @return the tags
     */
    public String getTags() {
        return tags;
    }

    /**
     * @param tags the tags to set
     */
    public void setTags(String tags) {
        this.tags = tags;
    }

    /**
     * @return the category
     */
    public String getCategory() {
        return category;
    }

    /**
     * @param category the category to set
     */
    public void setCategory(String category) {
        this.category = category;
    }

    /**
     * @return the protocols
     */
    public String getProtocols() {
        return protocols;
    }

    /**
     * @param protocols the protocols to set
     */
    public void setProtocols(String protocols) {
        this.protocols = protocols;
    }

    /**
     * @return the updated
     */
    public String getUpdated() {
        return updated;
    }

    /**
     * @param updated the updated to set
     */
    public void setUpdated(String updated) {
        this.updated = updated;
    }

    /**
     * @return the a1
     */
    public List<Api> getA1() {
        return a1;
    }

    /**
     * @param a1 the a1 to set
     */
    public void setA1(List<Api> a1) {
        this.a1 = a1;
    }

    /**
     * @return the a2
     */
    public List<Api> getA2() {
        return a2;
    }

    /**
     * @param a2 the a2 to set
     */
    public void setA2(List<Api> a2) {
        this.a2 = a2;
    }

    /**
     * @return the allSearch
     */
    public String getAllSearch() {
        return allSearch;
    }

    /**
     * @param allSearch the allSearch to set
     */
    public void setAllSearch(String allSearch) {
        this.allSearch = allSearch;
    }

    /**
     * @return the mashupTags
     */
    public String getMashupTags() {
        return mashupTags;
    }

    /**
     * @param mashupTags the mashupTags to set
     */
    public void setMashupTags(String mashupTags) {
        this.mashupTags = mashupTags;
    }

    /**
     * @return the mashupUpdated
     */
    public String getMashupUpdated() {
        return mashupUpdated;
    }

    /**
     * @param mashupUpdated the mashupUpdated to set
     */
    public void setMashupUpdated(String mashupUpdated) {
        this.mashupUpdated = mashupUpdated;
    }

    /**
     * @return the mashupAllSearch
     */
    public String getMashupAllSearch() {
        return mashupAllSearch;
    }

    /**
     * @param mashupAllSearch the mashupAllSearch to set
     */
    public void setMashupAllSearch(String mashupAllSearch) {
        this.mashupAllSearch = mashupAllSearch;
    }

    /**
     * @return the mashupApis
     */
    public String getMashupApis() {
        return mashupApis;
    }

    /**
     * @param mashupApis the mashupApis to set
     */
    public void setMashupApis(String mashupApis) {
        this.mashupApis = mashupApis;
    }

    /**
     * @return the a3
     */
    public List<Mashup> getA3() {
        return a3;
    }

    /**
     * @param a3 the a3 to set
     */
    public void setA3(List<Mashup> a3) {
        this.a3 = a3;
    }

    /**
     * @return the a4
     */
    public List<Mashup> getA4() {
        return a4;
    }

    /**
     * @param a4 the a4 to set
     */
    public void setA4(List<Mashup> a4) {
        this.a4 = a4;
    }

}
